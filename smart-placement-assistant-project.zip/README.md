# Smart Placement Preparation Assistant

A beginner-to-intermediate full-stack student project based on the supplied project guide. It helps students browse Python coding questions, record practice attempts, view progress and ask a predefined technical chatbot.

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: Python, FastAPI, Pydantic
- Database: MySQL
- Integration: JavaScript Fetch API + JSON
- Chatbot: Python keyword/rule-based responses (not Generative AI)

## Features
1. Browse 10 seeded Python programming questions.
2. Search and filter by category and difficulty.
3. View a question, sample input/output and record notes, score and completion status.
4. Store attempts persistently in MySQL.
5. View attempt count, completed count, average score and recent activity.
6. Ask the chatbot about greetings, Python, REST APIs, FastAPI, MySQL, interview preparation and help.
7. Backend validation, parameterized SQL and useful error messages.

## Requirements
- Python 3.10+
- MySQL Server 8.x (or compatible)
- A modern browser

## Setup

### 1. Create the database
Open MySQL Workbench or the MySQL command line and execute `database/schema.sql`.

The script creates the `placement_assistant` database, three tables, a demo student (ID 1), and 10 questions.

### 2. Configure the backend
Open a terminal in the project root:

```bash
cd backend
python -m venv venv
```

Activate the environment:

Windows:
```bash
venv\\Scripts\\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and update your MySQL password and settings. Do not commit `.env`.

Start the API:
```bash
uvicorn main:app --reload
```

Check:
- API status: http://127.0.0.1:8000/
- Interactive API docs: http://127.0.0.1:8000/docs
- Database health: http://127.0.0.1:8000/health

### 3. Run the frontend
Keep the backend running. Open a second terminal in the project root:

```bash
cd frontend
python -m http.server 5500
```

Open http://127.0.0.1:5500 in your browser.

The frontend calls the backend at `http://127.0.0.1:8000`. If you change the backend host or port, update `API_BASE` in `frontend/app.js`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Check backend |
| GET | `/health` | Check MySQL connection |
| GET | `/questions` | List questions; optional `category` and `difficulty` filters |
| GET | `/questions/{question_id}` | Get one question |
| POST | `/students` | Create a student |
| POST | `/attempts` | Save an attempt |
| GET | `/students/{student_id}/progress` | Get progress summary |
| POST | `/chat` | Get a predefined chatbot reply |

### Example requests

List questions:
```bash
curl http://127.0.0.1:8000/questions
```

Save an attempt:
```bash
curl -X POST http://127.0.0.1:8000/attempts ^
  -H "Content-Type: application/json" ^
  -d "{\\"student_id\\":1,\\"question_id\\":1,\\"submitted_answer\\":\\"print('olleh')\\",\\"score\\":80,\\"completed\\":true}"
```

Chat:
```json
POST /chat
{
  "message": "What is FastAPI?"
}
```

## Database design
- `students`: student profile details.
- `questions`: question title, category, difficulty, description and examples.
- `attempts`: student/question relationship, submitted answer, score, completion flag and timestamp.

The `attempts` table has foreign keys to `students` and `questions`.

## Demo flow
1. Open Home.
2. Open Practice and choose a question.
3. Enter notes or code, a score and completion status; save the attempt.
4. Open My Progress and verify that the attempt appears.
5. Open AI Assistant and ask “What is Python?” or “Explain REST API”.
6. Open `http://127.0.0.1:8000/docs` and demonstrate the API.

## Team roles (suggested for four members)
- Member 1: FastAPI endpoints, Python logic and Pydantic validation.
- Member 2: MySQL schema, sample data, SQL and persistence.
- Member 3: HTML/CSS screens, JavaScript and Fetch API.
- Member 4: Chatbot rules, integration tests, screenshots and documentation.

For a three-member team, combine chatbot/testing with frontend or backend. Every member should be able to explain the full application.

## Testing checklist
- [ ] Backend starts and `/docs` opens.
- [ ] `/health` reports database connected.
- [ ] `/questions` returns 10 questions.
- [ ] Invalid question ID returns 404.
- [ ] An attempt is stored in MySQL.
- [ ] Progress shows the saved attempt.
- [ ] Chatbot handles known and unknown topics.
- [ ] Empty chat input is not submitted.
- [ ] Frontend displays a helpful error if backend is stopped.
- [ ] SQL uses placeholders/parameters.
- [ ] `.env` and credentials are not committed.

## Limitations and future scope
- This is a learning/demo version with a seeded demo student; login and role-based access are not included.
- The chatbot is rule-based and does not generate new answers. A real LLM could later replace `get_reply()` through a backend-only integration, subject to API access and cost.
- Scores are entered by the student; code is not automatically executed or judged.
- For production, restrict CORS, add authentication, stronger authorization, logging and deployment configuration.

## Screenshots for submission
Capture at least these four screens after running the app:
1. Question list (`questions.html`)
2. Question detail modal
3. Progress page after saving at least one attempt
4. Chatbot with a sample response

## Security
Never commit passwords, API keys or `.env`. Use backend validation and parameterized SQL. Avoid collecting unnecessary personal information.
