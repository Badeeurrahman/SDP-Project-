"""Simple keyword-based chatbot. This is NOT a generative AI model."""

RULES = [
    (("hello", "hi", "hey"), "Hello! I am your Placement Preparation Assistant. Ask me about Python, REST APIs, FastAPI, MySQL or interview practice."),
    (("python",), "Python is a high-level, interpreted programming language. It is used in web development, automation, data science, machine learning and scripting. Important basics include variables, conditions, loops, functions, lists and dictionaries."),
    (("rest api", "api", "http"), "A REST API lets applications communicate over HTTP. Common methods are GET (read), POST (create), PUT/PATCH (update) and DELETE (remove). APIs commonly exchange JSON data."),
    (("fastapi",), "FastAPI is a Python framework for building APIs. It supports type hints, request validation with Pydantic, automatic interactive documentation at /docs and asynchronous programming."),
    (("mysql", "database", "sql"), "MySQL is a relational database. Data is stored in tables containing rows and columns. SQL commands include SELECT, INSERT, UPDATE and DELETE. Use parameterized queries to reduce SQL injection risk."),
    (("interview", "placement"), "For technical interviews, practise one or two coding problems daily, explain your approach and complexity, revise OOP, DBMS, OS, networking and your projects, and prepare a clear self-introduction."),
    (("help",), "I can answer predefined questions about Python, REST APIs, FastAPI, MySQL, interview preparation and placement practice. Try: 'What is Python?' or 'Explain REST API'."),
]

def get_reply(message: str) -> str:
    text = message.lower().strip()
    for keywords, reply in RULES:
        if any(keyword in text for keyword in keywords):
            return reply
    return ("I don't have a predefined answer for that question yet. "
            "Supported topics: Python, REST API, FastAPI, MySQL/database, interview and help.")
