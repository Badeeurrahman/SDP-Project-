import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from mysql.connector import Error
from dotenv import load_dotenv

from database import fetch_all, fetch_one, execute
from schemas import AttemptCreate, ChatRequest, StudentCreate
from chatbot import get_reply

load_dotenv()
app = FastAPI(title="Smart Placement Preparation Assistant", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For a college demo. Restrict this in production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DEMO_STUDENT_ID = int(os.getenv("DEMO_STUDENT_ID", "1"))

@app.get("/")
def home():
    return {"message": "Smart Placement Preparation Assistant API is running"}

@app.get("/health")
def health():
    try:
        fetch_one("SELECT 1 AS ok")
        return {"status": "ok", "database": "connected"}
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database unavailable: {exc}")

@app.get("/questions")
def list_questions(category: str | None = None, difficulty: str | None = None):
    query = "SELECT question_id, title, category, difficulty, description, sample_input, expected_output FROM questions"
    conditions, params = [], []
    if category:
        conditions.append("category = %s")
        params.append(category)
    if difficulty:
        conditions.append("difficulty = %s")
        params.append(difficulty)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY question_id"
    try:
        return fetch_all(query, params)
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}")

@app.get("/questions/{question_id}")
def get_question(question_id: int):
    try:
        question = fetch_one(
            """SELECT question_id, title, category, difficulty, description,
                      sample_input, expected_output
               FROM questions WHERE question_id = %s""",
            (question_id,),
        )
        if not question:
            raise HTTPException(status_code=404, detail="Question not found")
        return question
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}")

@app.post("/students", status_code=201)
def create_student(student: StudentCreate):
    try:
        student_id = execute(
            "INSERT INTO students (full_name, branch, study_year) VALUES (%s, %s, %s)",
            (student.full_name, student.branch, student.study_year),
        )
        return {"student_id": student_id, "message": "Student created"}
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}")

@app.post("/attempts", status_code=201)
def save_attempt(attempt: AttemptCreate):
    try:
        if not fetch_one("SELECT student_id FROM students WHERE student_id = %s", (attempt.student_id,)):
            raise HTTPException(status_code=404, detail="Student not found")
        if not fetch_one("SELECT question_id FROM questions WHERE question_id = %s", (attempt.question_id,)):
            raise HTTPException(status_code=404, detail="Question not found")
        attempt_id = execute(
            """INSERT INTO attempts
               (student_id, question_id, submitted_answer, score, completed)
               VALUES (%s, %s, %s, %s, %s)""",
            (attempt.student_id, attempt.question_id, attempt.submitted_answer,
             attempt.score, attempt.completed),
        )
        return {"attempt_id": attempt_id, "message": "Attempt saved successfully"}
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}")

@app.get("/students/{student_id}/progress")
def student_progress(student_id: int):
    try:
        student = fetch_one("SELECT student_id, full_name FROM students WHERE student_id = %s", (student_id,))
        if not student:
            raise HTTPException(status_code=404, detail="Student not found")
        summary = fetch_one(
            """SELECT COUNT(*) AS attempts,
                      SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) AS completed,
                      ROUND(AVG(score), 2) AS average_score,
                      MAX(attempted_at) AS last_attempt
               FROM attempts WHERE student_id = %s""",
            (student_id,),
        )
        recent = fetch_all(
            """SELECT q.title, a.score, a.completed, a.attempted_at
               FROM attempts a JOIN questions q ON q.question_id = a.question_id
               WHERE a.student_id = %s ORDER BY a.attempted_at DESC LIMIT 10""",
            (student_id,),
        )
        return {"student": student, "summary": summary, "recent_attempts": recent}
    except Error as exc:
        raise HTTPException(status_code=503, detail=f"Database error: {exc}")

@app.post("/chat")
def chat(request: ChatRequest):
    return {"reply": get_reply(request.message)}
