from pydantic import BaseModel, Field
from typing import Optional

class AttemptCreate(BaseModel):
    student_id: int = Field(gt=0)
    question_id: int = Field(gt=0)
    submitted_answer: Optional[str] = Field(default="", max_length=10000)
    score: float = Field(default=0, ge=0, le=100)
    completed: bool = False

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

class StudentCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)
    branch: str = Field(default="CSE", max_length=60)
    study_year: int = Field(default=2, ge=1, le=6)
