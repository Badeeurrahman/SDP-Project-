const API_BASE = "http://127.0.0.1:8000";
const DEMO_STUDENT_ID = 1;
const $ = (id) => document.getElementById(id);

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

let allQuestions = [];
let selectedQuestion = null;

async function loadQuestions() {
  const list = $("questionList");
  if (!list) return;
  try {
    allQuestions = await api("/questions");
    if ($("totalQuestions")) $("totalQuestions").textContent = allQuestions.length;
    if ($("questionCount")) $("questionCount").textContent = `${allQuestions.length}+`;
    const categories = [...new Set(allQuestions.map(q => q.category))];
    const filter = $("categoryFilter");
    if (filter) categories.forEach(c => filter.insertAdjacentHTML("beforeend", `<option>${escapeHTML(c)}</option>`));
    renderQuestions();
  } catch (error) {
    list.innerHTML = `<div class="loading">Unable to load questions. ${escapeHTML(error.message)}<br>Start the FastAPI backend and check your MySQL connection.</div>`;
  }
}
function renderQuestions() {
  const list = $("questionList");
  if (!list) return;
  const term = ($("searchInput")?.value || "").toLowerCase();
  const category = $("categoryFilter")?.value || "";
  const difficulty = $("difficultyFilter")?.value || "";
  const filtered = allQuestions.filter(q =>
    (`${q.title} ${q.description} ${q.category}`).toLowerCase().includes(term) &&
    (!category || q.category === category) && (!difficulty || q.difficulty === difficulty)
  );
  list.innerHTML = filtered.length ? filtered.map(q => `
    <article class="question-card" data-id="${q.question_id}">
      <div class="question-meta"><span class="tag">${escapeHTML(q.category)}</span><span class="tag gray">${escapeHTML(q.difficulty)}</span></div>
      <h3>${escapeHTML(q.question_id)}. ${escapeHTML(q.title)}</h3>
      <p>${escapeHTML(q.description)}</p><span class="open-label">Open question →</span>
    </article>`).join("") : '<div class="loading">No matching questions found.</div>';
  list.querySelectorAll(".question-card").forEach(card => card.addEventListener("click", () => openQuestion(Number(card.dataset.id))));
}
async function openQuestion(id) {
  try {
    selectedQuestion = await api(`/questions/${id}`);
    $("modalTitle").textContent = selectedQuestion.title;
    $("modalMeta").innerHTML = `<span class="tag">${escapeHTML(selectedQuestion.category)}</span><span class="tag gray">${escapeHTML(selectedQuestion.difficulty)}</span>`;
    $("modalDescription").textContent = selectedQuestion.description;
    $("modalInput").textContent = selectedQuestion.sample_input || "Not provided";
    $("modalOutput").textContent = selectedQuestion.expected_output || "Not provided";
    $("answerInput").value = ""; $("scoreInput").value = 0; $("completedInput").checked = false;
    $("modalMessage").textContent = "";
    $("questionModal").classList.remove("hidden");
  } catch (error) { alert(error.message); }
}
async function saveAttempt() {
  if (!selectedQuestion) return;
  const score = Number($("scoreInput").value);
  if (!Number.isFinite(score) || score < 0 || score > 100) {
    $("modalMessage").textContent = "Please enter a score between 0 and 100."; return;
  }
  try {
    await api("/attempts", {method:"POST", body:JSON.stringify({
      student_id: DEMO_STUDENT_ID, question_id: selectedQuestion.question_id,
      submitted_answer: $("answerInput").value, score,
      completed: $("completedInput").checked
    })});
    $("modalMessage").textContent = "✓ Attempt saved. Visit My Progress to see your updated summary.";
  } catch (error) { $("modalMessage").textContent = error.message; }
}
async function loadProgress() {
  const container = $("progressContent");
  if (!container) return;
  try {
    const data = await api(`/students/${DEMO_STUDENT_ID}/progress`);
    const s = data.summary || {};
    const recent = data.recent_attempts || [];
    container.innerHTML = `
      <div class="progress-cards">
        <div class="progress-card"><span>Total attempts</span><strong>${s.attempts || 0}</strong></div>
        <div class="progress-card"><span>Questions completed</span><strong>${s.completed || 0}</strong></div>
        <div class="progress-card"><span>Average score</span><strong>${s.average_score ?? "—"}${s.average_score !== null ? "%" : ""}</strong></div>
      </div>
      <section class="table-wrap"><h3>Recent practice activity</h3>
      ${recent.length ? `<table><thead><tr><th>Question</th><th>Score</th><th>Status</th><th>Attempted at</th></tr></thead><tbody>
      ${recent.map(a => `<tr><td>${escapeHTML(a.title)}</td><td>${a.score ?? 0}%</td><td><span class="${a.completed ? "status-done" : "status-pending"}">${a.completed ? "Completed" : "In progress"}</span></td><td>${a.attempted_at ? new Date(a.attempted_at).toLocaleString() : "—"}</td></tr>`).join("")}
      </tbody></table>` : '<div class="empty-state">No attempts yet. Open Practice and save your first attempt.</div>'}</section>`;
  } catch (error) {
    container.innerHTML = `<div class="loading">Unable to load progress: ${escapeHTML(error.message)}. Make sure the backend and database are running.</div>`;
  }
}
async function sendChat(message) {
  const messages = $("chatMessages");
  if (!message.trim()) return;
  messages.insertAdjacentHTML("beforeend", `<div class="message user">${escapeHTML(message)}</div>`);
  $("chatInput").value = "";
  messages.scrollTop = messages.scrollHeight;
  try {
    const result = await api("/chat", {method:"POST", body:JSON.stringify({message})});
    messages.insertAdjacentHTML("beforeend", `<div class="message bot">${escapeHTML(result.reply)}</div>`);
  } catch (error) {
    messages.insertAdjacentHTML("beforeend", `<div class="message bot">Sorry, the assistant could not connect: ${escapeHTML(error.message)}</div>`);
  }
  messages.scrollTop = messages.scrollHeight;
}

document.addEventListener("DOMContentLoaded", () => {
  loadQuestions(); loadProgress();
  ["searchInput","categoryFilter","difficultyFilter"].forEach(id => $(id)?.addEventListener(id === "searchInput" ? "input" : "change", renderQuestions));
  $("closeModal")?.addEventListener("click", () => $("questionModal").classList.add("hidden"));
  $("questionModal")?.addEventListener("click", e => { if (e.target.id === "questionModal") $("questionModal").classList.add("hidden"); });
  $("saveAttempt")?.addEventListener("click", saveAttempt);
  $("chatForm")?.addEventListener("submit", e => { e.preventDefault(); sendChat($("chatInput").value); });
  document.querySelectorAll(".suggestion").forEach(button => button.addEventListener("click", () => sendChat(button.textContent)));
});
