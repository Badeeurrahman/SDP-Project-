CREATE DATABASE IF NOT EXISTS placement_assistant;
USE placement_assistant;

CREATE TABLE IF NOT EXISTS students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    branch VARCHAR(60),
    study_year INT
);

CREATE TABLE IF NOT EXISTS questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(60) NOT NULL,
    difficulty VARCHAR(20) DEFAULT 'Beginner',
    description TEXT NOT NULL,
    sample_input TEXT,
    expected_output TEXT
);

CREATE TABLE IF NOT EXISTS attempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    question_id INT NOT NULL,
    submitted_answer TEXT,
    score DECIMAL(5,2) DEFAULT 0,
    completed BOOLEAN DEFAULT FALSE,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (question_id) REFERENCES questions(question_id)
);

INSERT INTO students (student_id, full_name, branch, study_year)
SELECT 1, 'Demo Student', 'CSE', 2
WHERE NOT EXISTS (SELECT 1 FROM students WHERE student_id = 1);

INSERT INTO questions (title, category, difficulty, description, sample_input, expected_output)
SELECT * FROM (
    SELECT 'Reverse a String', 'Strings', 'Beginner',
           'Write a program to reverse the given string.',
           'hello', 'olleh'
    UNION ALL SELECT 'Check Palindrome', 'Strings', 'Beginner',
           'Check whether a string reads the same forward and backward.',
           'madam', 'Palindrome'
    UNION ALL SELECT 'Count Vowels', 'Strings', 'Beginner',
           'Count the vowels (a, e, i, o, u) in a string.',
           'placement', '3'
    UNION ALL SELECT 'Find Largest Number', 'Numbers', 'Beginner',
           'Find the largest among three integers.',
           '4 9 2', '9'
    UNION ALL SELECT 'Factorial', 'Numbers', 'Beginner',
           'Calculate the factorial of a non-negative integer.',
           '5', '120'
    UNION ALL SELECT 'Sum of List Elements', 'Lists', 'Beginner',
           'Calculate the sum of all integers in a list.',
           '1 2 3 4', '10'
    UNION ALL SELECT 'Remove Duplicates', 'Lists', 'Intermediate',
           'Remove duplicate values while preserving the original order.',
           '1 2 2 3 1', '1 2 3'
    UNION ALL SELECT 'Character Frequency', 'Dictionaries', 'Intermediate',
           'Count how many times each character occurs in a string.',
           'apple', 'a:1, p:2, l:1, e:1'
    UNION ALL SELECT 'Prime Number', 'Numbers', 'Beginner',
           'Determine whether a given integer is prime.',
           '7', 'Prime'
    UNION ALL SELECT 'Fibonacci Series', 'Functions', 'Intermediate',
           'Print the first n terms of the Fibonacci sequence.',
           '6', '0 1 1 2 3 5'
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM questions LIMIT 1);
